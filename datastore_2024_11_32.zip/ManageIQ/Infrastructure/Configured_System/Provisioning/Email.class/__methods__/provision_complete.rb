#
# Description: Place holder for Provision Complete email #
#
$evm.log("warn", "[DEPRECATION] This method will be deprecated. Please use similarly named method from System/Notification/Email class.")
